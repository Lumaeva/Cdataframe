/*This is the beginning od the CDataFrame in C, made by Vincent QU and Ellie BOUCHAREL.*/

//compile line : "D:\IDE\mingw64\bin\gcc.exe" "D:\Indie\school\CDataFrame\main.c" -o "D:\Indie\school\CDataFrame\main.exe"
/*----------------------------------------------------------------------------*/
GitHub: https://github.com/Lumaeva/Cdataframe.git

Notre equipe est compose de deux membres en L, section BN. Nous sommes Vincent QU et Elie BOUCHAREL.

L’objectif de ce projet est de créer un ensemble de fonctions en langage C (appelées communément
une librairie) qui permettent de faciliter la manipulation de données.

Jusqu'a l'ordre de 2024/4/22, nous avons reussis a creer les deux fichiers headers: column.h et cdataframe.h. Nous avons aussi reussi a creer le fichier source: main.c.
Avec quelque manipulation de la ligne de commande et gcc.exe, nous compilons le programme et nous sortons en resultat le fichier executable main.exe.
Ce fichier source main.c presente quelques exemples d application concernant les fonctions liee a la colonne du dataframe. Donc les prtotypes des fonctions se trouvent, ainsi qu'avec leur programme dans le fichier header column.h.
Concernant le fichier header cdataframe, il est vide car nous n'avons pas compris ce qu nous devions faire. les questions exposees au point 4.1.2 nous paraissent trops abstraites et trops nombreuses. Nous rattraperonsce contenus avec la partie 2, puisque ce passage semble avoir un lien avec la partie 2.

A l execution du programme redige dans le fichier source main.c, tout se qui est affiche est execute de maniere lineaire. Donc pour comprendre l'affichange dans la ligne de commande, il suffirait de lire les differentes fonctions inscrites dans le fichier header column.h fait pour cela.