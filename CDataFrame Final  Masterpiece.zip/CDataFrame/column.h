#ifndef COLUMN_H
#define COLUMN_H


//only int



/*
typedef struct {
	char* title;
	int* data;
	int size;
}COLUMN;


OLD_COLUMN* create_column(char* title);
int insert_value(COLUMN* col, int value);
void delete_column(COLUMN **col);
void print_col(COLUMN* col);
void occurence_value(COLUMN* col, int value);
void position_value(COLUMN* col, int value);
void superior_value(COLUMN* col, int value);
void inferior_value(COLUMN* col, int value);
void equal_value(COLUMN* col, int value);







OLD_COLUMN* create_column(char* title){
	COLUMN* col = (COLUMN*)malloc(sizeof(COLUMN));
	
	if (col == NULL) {
		perror("Erreur d'allocation de mémoire pour la colonne");
		return NULL;
	}

	col-> title = strdup(title);
	if (col->title == NULL) {
		perror("Erreur d'allocation de mémoire pour le titre de la colonne");
		free(col);
		return NULL; 
	}

	col-> size = 0;
	col-> data = NULL;
	return col;
}

int insert_value(COLUMN* col, int value){
	if (col->size % 256 == 0 || col->size == 0){
		int* new_data = (int*)realloc(col->data, (col->size + 256) * sizeof(int));
		if (new_data == NULL) {
			perror("Erreur de ré-allocation de mémoire pour les données de la colonne");
			return 0; 
        	}

		col->data = new_data;
	}
	col->data[col->size] = value;
	col->size++;
	return 1;
}

void delete_column(COLUMN **col){
	if (*col == NULL){
		return;
	}
	free((*col)->title);
	free((*col)->data);
	free(*col);
}

void print_col(COLUMN* col){
	printf("Voici la colonne imprime en dessous: %s\n",col->title);
	for (int i = 0; i< col->size; i++){
		printf("[%d]   %d\n", i, col->data[i]);
	}
	printf("\n");
}

void occurence_value(COLUMN* col, int value){
	int count = 0;
	for (int i = 0; i < col->size; i++){
		if (col->data[i] == value){
			count++;
		}
	}
	printf("le nombre d'occurence de %d est %d\n\n", value, count);
}

void position_value(COLUMN* col, int value){
	int* position = (int*)malloc((col->size)* sizeof(int));
	if (position == NULL) {
		perror("Erreur d'allocation de mémoire pour le tableau de positions");
		return;
    }
	int count = 0;
	for (int i = 0; i < col->size; i++){
		if (col->data[i] == value){
			position[count] = i;
			count++;
		}
	}
	position = (int*)realloc(position, count * sizeof(int));
	if (position == NULL) {
		perror("Erreur de ré-allocation de mémoire pour le tableau de positions");
		free(position); 
		return;
	}
	for (int i = 0; i<count; i++){
		printf("la position de %d se trouve sur la ligne %d de la colonne '%s'\n", value, position[i], col->title);
	}
	printf("\n");
}

void superior_value(COLUMN* col, int value){
	int count = 0;
	for (int i = 0; i < col->size; i++){
		if (col->data[i] > value){
			count++;
		}
	}
	printf("le nombre de valeur superieur a %d est %d\n\n", value, count);
}

void inferior_value(COLUMN* col, int value){
	int count = 0;
	for (int i = 0; i < col->size; i++){
		if (col->data[i] < value){
			count++;
		}
	}
	printf("le nombre de valeur inferieur a %d est %d\n\n", value, count);
}

void equal_value(COLUMN* col, int value){
	int count = 0;
	for (int i = 0; i< col->size; i++){
		if (col->data[i] == value){
			count++;
		}
	}
	printf("le nombre de valeur egal a %d est %d\n\n", value, count);
}



*/



//all type




enum enum_type {
    NULLVAL = 1, UINT, INT, CHAR, FLOAT, DOUBLE, STRING, STRUCTURE
};
typedef enum enum_type ENUM_TYPE;


typedef union column_type {
    unsigned int uint_value;
    signed int int_value;
    char char_value;
    float float_value;
    double double_value;
    char *string_value;
    void *struct_value;
} COL_TYPE;

typedef struct {
    char *title;
    unsigned int size;
    unsigned int max_size;
    ENUM_TYPE column_type;
    COL_TYPE **data; 
    unsigned long long int *index;
} COLUMN;


COLUMN *create_column(ENUM_TYPE type, char *title);
int insert_value(COLUMN *col, void *value);
void convert_value(COLUMN *col, unsigned long long int i, char *str, int size);
void print_col(COLUMN* col);


COLUMN *create_column(ENUM_TYPE type, char *title) {
    COLUMN *new_column = (COLUMN *)malloc(sizeof(COLUMN));
    if (new_column == NULL) {
        return NULL;
    }
    new_column->title = strdup(title);
    if (new_column->title == NULL) {
        free(new_column);
        return NULL;
    }
    new_column->size = 0;
    new_column->max_size = 0;
    new_column->column_type = type;
    new_column->data = (COL_TYPE **)malloc(new_column->max_size * sizeof(COL_TYPE *));
    new_column->index = (unsigned long long int *)malloc(new_column->max_size * sizeof(unsigned long long int));
    if (new_column->data == NULL || new_column->index == NULL) {
        free(new_column->title);
        free(new_column->data);
        free(new_column->index);
        free(new_column);
        return NULL;
    }
    for (unsigned int i = 0; i < new_column->max_size; i++) {
        new_column->data[i] = NULL;
    }
    return new_column;
}

int insert_value(COLUMN *col, void *value) {
    if (col == NULL || value == NULL) {
        return 0;
    }
    
    if (col->size >= col->max_size) {
        unsigned int new_max_size = col->max_size + 256;
        COL_TYPE **new_data = (COL_TYPE **)realloc(col->data, new_max_size * sizeof(COL_TYPE *));
        unsigned long long int *new_index = (unsigned long long int *)realloc(col->index, new_max_size * sizeof(unsigned long long int));
        if (new_data == NULL || new_index == NULL) {
            return 0;
        }
        col->data = new_data;
        col->index = new_index;
        col->max_size = new_max_size;
    }
    
    col->data[col->size] = (COL_TYPE *)malloc(sizeof(COL_TYPE));
    if (col->data[col->size] == NULL) {
        return 0; 
    }
    
    switch (col->column_type) {
        case UINT:
            col->data[col->size]->uint_value = *((unsigned int *)value);
            break;
        case INT:
            col->data[col->size]->int_value = *((int *)value);
            break;
        case CHAR:
            col->data[col->size]->char_value = *((char *)value);
            break;
        case FLOAT:
            col->data[col->size]->float_value = *((float *)value);
            break;
        case DOUBLE:
            col->data[col->size]->double_value = *((double *)value);
            break;
        case STRING:
            col->data[col->size]->string_value = strdup((char *)value);
            if (col->data[col->size]->string_value == NULL) {
                free(col->data[col->size]);
                return 0; 
            }
            break;
	case STRUCTURE:
            col->data[col->size]->struct_value = value;
            break;
        default:
            free(col->data[col->size]);
            return 0;
    }
    
    col->size++;
    return 1;
}

void convert_value(COLUMN *col, unsigned long long int i, char *str, int size){
	switch (col->column_type){
		case UINT:
			snprintf(str, size, "%u", col->data[i]->uint_value);
			break;
        	case INT:
			snprintf(str, size, "%d", col->data[i]->int_value);
			break;
        	case CHAR:
			snprintf(str, size, "%c", col->data[i]->char_value);
			break;
        	case FLOAT:
			snprintf(str, size, "%f", col->data[i]->float_value);
			break;
        	case DOUBLE:
			snprintf(str, size, "%lf", col->data[i]->double_value);
			break;
        	case STRING:
			snprintf(str, size, "%s", col->data[i]->string_value);
			break;
		default:
			snprintf(str, size, "Unknown type");
			break;
	}
}

void delete_column(COLUMN **col) {
    if (*col == NULL) {
        return;
    }
    free((*col)->title);
    for (size_t i = 0; i < (*col)->size; ++i) {
        if ((*col)->column_type == STRING) {
            free((*col)->data[i]->string_value);
        }
        free((*col)->data[i]);
    }
    free((*col)->data);
    free(*col);
    *col = NULL;
}


void print_col(COLUMN* col) {
    char buffer[col->size]; 
    for (size_t i = 0; i < col->size; i++) {
        convert_value(col, i, buffer, sizeof(buffer));
        printf("[%d] %s\n", col->index[i], buffer);
    }
}

void position_value(COLUMN *col, int value) {
    printf("Positions of value %d in column '%s':\n", value, col->title);
    for (unsigned int i = 0; i < col->size; ++i) {
        if (col->column_type == INT && col->data[i]->int_value == value) {
            printf("%llu\n", col->index[i]);
        }
    }
}

void superior_value(COLUMN *col, int value) {
    int count = 0;
    for (unsigned int i = 0; i < col->size; ++i) {
        if (col->column_type == INT && col->data[i]->int_value > value) {
            count++;
        }
    }
    printf("Number of values superior to %d in column '%s': %d\n", value, col->title, count);
}

void inferior_value(COLUMN *col, int value) {
    int count = 0;
    for (unsigned int i = 0; i < col->size; ++i) {
        if (col->column_type == INT && col->data[i]->int_value < value) {
            count++;
        }
    }
    printf("Number of values inferior to %d in column '%s': %d\n", value, col->title, count);
}

void equal_value(COLUMN *col, int value) {
    int count = 0;
    for (unsigned int i = 0; i < col->size; ++i) {
        if (col->column_type == INT && col->data[i]->int_value == value) {
            count++;
        }
    }
    printf("Number of values equal to %d in column '%s': %d\n", value, col->title, count);
}

#endif