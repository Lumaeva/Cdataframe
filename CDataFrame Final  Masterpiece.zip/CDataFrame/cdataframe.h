#ifndef CDATAFRAME_H
#define CDATAFRAME_H

int create_df() {
    int reponse = -1;
    printf("\n\n\n\n\nDear teacher, we made this project with our heart, but we didn t have enough time to finish itas we put ourselves into the challenges of trying to do everything we could in the proposed PDF. So, if you investigate the source or headers file, you might see some function that aren t used in the main source file, that is because we were free of using our imagination to try and create new function adapted to our style of writing. So this is kind of a early version of our finished product. Thank you for using our product, the hardest part, we think has been the last part and the second part of the project. We want to be honest, there were some things in the code that were hard to get over, so we sometime asked help from ChatGPT, please don t get mad at us, we truly put our everything we could to build this project independently before asking help from ChatGPT. We hope you like our hard work. Sincerily, Elie BOUCHAREL and Vincent QU\n\n\n\n");
    printf("Would you like to create a DATAFRAME ? \n 1 = [YES]\n 0 = [NO]\n\nYour choice: ");
    scanf("%d", &reponse);
    printf("\n\n\n");
    if (reponse > 0) {
        reponse = 0;
        printf("Seems like you have chosen to create a new DataFrame, am I right ?\n1 = [YES]\n0 = [NO]\n\nYour choice: ");
        scanf("%d", &reponse);
        printf("\n\n\n");
        if (reponse > 0) {
            printf("Alright, lets get started!\n");
            return 1;
        } else {
            printf("Seems like you were joking. Good Bye.\n");
            return 0;
        }
    } else {
        printf("Seems like you aren't interested in creating a DataFrame yet.\n");
        return 0;
    }
}

int first_lobby() {
    int choice = -1;
    printf("Would you like to create a column or exit the program?\n\n1.  Add a column\n0.  Exit.\n\nYour choice: ");
    scanf("%d", &choice);
    printf("\n\n\n");
    return choice;
}

int second_lobby() {
    int choice = -1;
    printf("What would you like to do ? Please choose one of the following option:\n\n1.  Input a data\n2.  Print the DataFrame\n3.  Show some row from the DataFrame\n4.  Show some column from the DataFrame\n5.  Add a row\n6.  Add a column\n7.  Delete a row\n8.  Delete a column\n9.  Rename a column\n10. Search a data\n11. Modify a data\n12. Print title of column\n13. Print number of rows\n14. Print number of column\n15. Print number of value superior to searched data\n16. Print number of value inferior to searched data\n17. Print number of value equal to searched data\n0.  Exit.\n\nYour option: ");
    scanf("%d", &choice);
    printf("\n\n\n");
    return choice;
}

int third_lobby() {
    int choice = -1;
    printf("1. Type the name of the DataFrame(max characters :256)\n0. Exit.\n\nYour choice: ");
    scanf("%d", &choice);
    printf("\n\n\n");
    return choice;
}

int fourth_lobby() {
    int choice = -1;
    printf("1. Add row\n0. Exit.\n\nYour choice: ");
    scanf("%d", &choice);
    printf("\n\n\n");
    return choice;
}

typedef union array_naming {
    unsigned int uint_value;
    signed int int_value;
    char char_value;
    float float_value;
    double double_value;
    char *string_value;
    void *struct_value;
    COLUMN *column_value; 
} ARRAY_NAME;


typedef struct {
    char *title;
    unsigned int size;
    unsigned int max_size;
    ARRAY_NAME **name;
    unsigned long long int *index;
} ARRAY;

ARRAY *create_array(char *title) {
    ARRAY *new_array = (ARRAY *)malloc(sizeof(ARRAY));
    if (new_array == NULL) {
        return NULL;
    }

    new_array->title = strdup(title);
    if (new_array->title == NULL) {
        free(new_array);
        return NULL;
    }

    new_array->size = 0;
    new_array->max_size = 10;
    new_array->name = (ARRAY_NAME **)malloc(new_array->max_size * sizeof(ARRAY_NAME *));
    new_array->index = (unsigned long long int *)malloc(new_array->max_size * sizeof(unsigned long long int));
    if (new_array->name == NULL || new_array->index == NULL) {
        free(new_array->title);
        free(new_array->name);
        free(new_array->index);
        free(new_array);
        return NULL;
    }

    for (unsigned int i = 0; i < new_array->max_size; i++) {
        new_array->name[i] = NULL;
    }

    return new_array;
}

void add_column_to_array(ARRAY *first_array) {
    if (first_array->size < first_array->max_size) {
        for (unsigned int i = 0; i < first_array->max_size; i++) {
            COLUMN *new_column = create_column(INT, "New Column"); // Create a new column
            if (new_column != NULL) {
                first_array->name[first_array->size]->column_value = new_column;  // Add the new column to the array
                first_array->index[first_array->size] = first_array->size;  // Set the index of the new column
                first_array->size++;  // Increment the size of the array
                break;  // Exit loop after adding one column
            } else {
                printf("Error: Failed to create a new column.\n");
            }
        }
    } else {
        first_array->max_size *= 2;  // Double the max size of the array
        first_array->name = (ARRAY_NAME **)realloc(first_array->name, first_array->max_size * sizeof(ARRAY_NAME *));
        first_array->index = (unsigned long long int *)realloc(first_array->index, first_array->max_size * sizeof(unsigned long long int));
        if (first_array->name == NULL || first_array->index == NULL) {
            printf("Error: Failed to reallocate memory for the array.\n");
            return;
        }
        add_column_to_array(first_array);
    }
}

void free_array(ARRAY *array) {
    if (array == NULL) {
        return;
    }
    free(array->title);

    for (unsigned int i = 0; i < array->size; i++) {
        if (array->name[i] != NULL && array->name[i]->column_value != NULL) {
            free(array->name[i]->column_value->title);
            free(array->name[i]->column_value);
        }
    }
    free(array->name);
    free(array->index);
    free(array);
}

#endif
