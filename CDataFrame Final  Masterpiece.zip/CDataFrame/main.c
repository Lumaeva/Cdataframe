#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "column.h"
#include "cdataframe.h"
#include <stdbool.h>

int main() {
    int running = 1;
    int existing_array = 0;
    int existing_column = 0;
    int existing_row = 0;
    int df_created = -1;
    char column_title[255];
    char array_name[255];
    COLUMN *first_column = NULL; 
    while (running) {
        if (df_created < 0) {
            df_created = create_df();
        } else if (df_created == 0) {
            running = 0;
        } else {
            if (df_created == 1 && existing_array == 1) {
                if (df_created == 1 && existing_column == 1 && existing_row == 1) {
                    switch (second_lobby()) {
                        case 0:
                            running = 0;
                            break;
                        case 1: {
                            // Input a data
                            int value;
                            printf("Enter value to insert: ");
                            scanf("%d", &value);
                            insert_value(first_column, &value);
                            existing_row = 1;
                            break;
                        }
                        case 2:
                            // Print the DataFrame
                            print_col(first_column);
                            break;
                        case 3: {
                            // Show some row from the DataFrame
                            int row;
                            printf("Enter row index: ");
                            scanf("%d", &row);
                            if (row < first_column->size) {
                                char buffer[255];
                                convert_value(first_column, row, buffer, sizeof(buffer));
                                printf("Row %d: %s\n", row, buffer);
                            } else {
                                printf("Row index out of range.\n");
                            }
                            break;
                        }
                        case 4:
                            // Show some column from the DataFrame
                            print_col(first_column);
                            break;
                        case 5: {
                            // Add a row
                            int value;
                            printf("Enter value to insert: ");
                            scanf("%d", &value);
                            insert_value(first_column, &value);
                            existing_row = 1;
                            break;
                        }
                        case 6:
                            // Add a column
                            if (first_column != NULL) {
                                printf("Column already exists.\n");
                            } else {
                                int type;
                                printf("Title of column (max: 256 characters): ");
                                scanf("%s", column_title);
                                printf("Type of column:\n1.[INT] 2.[UINT] 3.[CHAR] 4.[FLOAT] 5.[DOUBLE] 6.[STRING] 7.[STRUCTURE]\nYour choice: ");
                                scanf("%d", &type);
                                first_column = create_column(type, column_title);
                                existing_column = 1;
                            }
                            break;
                        case 7:
                            // Delete a row
                            if (first_column->size > 0) {
                                first_column->size--;
                            } else {
                                printf("No rows to delete.\n");
                            }
                            break;
                        case 8:
                            // Delete a column
                            delete_column(&first_column);
                            existing_column = 0;
                            existing_row = 0;
                            break;
                        case 9:
                            // Rename a column
                            if (first_column != NULL) {
                                printf("Enter new title: ");
                                scanf("%s", column_title);
                                free(first_column->title);
                                first_column->title = strdup(column_title);
                            }
                            break;
                        case 10: {
                            // Search a data
                            int value;
                            printf("Enter value to search: ");
                            scanf("%d", &value);
                            position_value(first_column, value);
                            break;
                        }
                        case 11: {
                            // Modify a data
                            int index, value;
                            printf("Enter index to modify: ");
                            scanf("%d", &index);
                            printf("Enter new value: ");
                            scanf("%d", &value);
                            if (index < first_column->size) {
                                first_column->data[index]->int_value = value; // Assuming INT type for simplicity
                            } else {
                                printf("Index out of range.\n");
                            }
                            break;
                        }
                        case 12:
                            // Print title of column
                            printf("Title: %s\n", first_column->title);
                            break;
                        case 13:
                            // Print number of rows
                            printf("Number of rows: %u\n", first_column->size);
                            break;
                        case 14:
                            // Print number of columns
                            printf("Number of columns: 1\n"); // Assuming single column for simplicity
                            break;
                        case 15: {
                            // Print number of values superior to searched data
                            int value;
                            printf("Enter value: ");
                            scanf("%d", &value);
                            superior_value(first_column, value);
                            break;
                        }
                        case 16: {
                            // Print number of values inferior to searched data
                            int value;
                            printf("Enter value: ");
                            scanf("%d", &value);
                            inferior_value(first_column, value);
                            break;
                        }
                        case 17: {
                            // Print number of values equal to searched data
                            int value;
                            printf("Enter value: ");
                            scanf("%d", &value);
                            equal_value(first_column, value);
                            break;
                        }
                    }
                } else if (df_created == 1 && existing_column == 1 && existing_row == 0) {
                    switch (fourth_lobby()) {
                        case 1:
                            if (first_column->size >= first_column->max_size) {
                                first_column->max_size *= 2;
                                first_column->data = realloc(first_column->data, first_column->max_size * sizeof(void *));
                                
                                for (unsigned int i = first_column->size; i < first_column->max_size; ++i) {
                                    first_column->data[i] = NULL;
                                }
                            }
                            first_column->size++;
                            existing_row = 1;
                            break;
                        case 0:
                            running = 0;
                            break;
                    }
                } else if (df_created == 1 && existing_array == 1 && existing_column == 0) {
                    switch (first_lobby()) {
                        case 0:
                            running = 0;
                            break;
                        case 1:
                            int type = 0;
                            printf("Title of column (max: 256 characters): ");
                            scanf("%s", column_title);
                            printf("Type of column:\n1.[INT] 2.[UINT] 3.[CHAR] 4.[FLOAT] 5.[DOUBLE] 6.[STRING] 7.[STRUCTURE]\nYour choice: ");
                            scanf("%d", &type);
                            first_column = create_column(type, column_title);
                            existing_column = 1;
                            break;
                    }
                }
            } else if (df_created == 1 && existing_array == 0) {
                switch (third_lobby()) {
                    case 1:
                        printf("Type the name of the DataFrame: ");
                        scanf("%s", array_name);
                        existing_array = 1;
                        break;
                    case 0:
                        running = 0;
                        break;
                }
            }
        }
    }
    
    return 0;
}
